<?php
$con=mysqli_connect("localhost","codegvgr_milk","manish@123","codegvgr_milk");


?>